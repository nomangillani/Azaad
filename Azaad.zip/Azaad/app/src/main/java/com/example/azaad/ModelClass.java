package com.example.azaad;

public class ModelClass {
    String name,city,country,age,caste,education,profession,income,skintone,height,family,bio,e_cast,e_education,e_profession,e_skintone,e_height;
    String imagea,imageb,imagec,imaged,imagee,imagef;

    public ModelClass(String name, String city, String country, String age, String caste, String education, String profession, String income, String skintone, String height, String family, String bio, String imagea, String imageb, String imagec, String imaged, String imagee, String imagef) {
        this.name = name;
        this.city = city;
        this.country = country;
        this.age = age;
        this.caste = caste;
        this.education = education;
        this.profession = profession;
        this.income = income;
        this.skintone = skintone;
        this.height = height;
        this.family = family;
        this.bio = bio;
        this.imagea = imagea;
        this.imageb = imageb;
        this.imagec = imagec;
        this.imaged = imaged;
        this.imagee = imagee;
        this.imagef = imagef;
    }

    public ModelClass(String name, String city, String country, String age, String caste, String education, String profession, String income, String skintone, String height, String family, String bio, String e_cast, String e_education, String e_profession, String e_skintone, String e_height, String imagea, String imageb, String imagec, String imaged, String imagee, String imagef) {
        this.name = name;
        this.city = city;
        this.country = country;
        this.age = age;
        this.caste = caste;
        this.education = education;
        this.profession = profession;
        this.income = income;
        this.skintone = skintone;
        this.height = height;
        this.family = family;
        this.bio = bio;
        this.e_cast = e_cast;
        this.e_education = e_education;
        this.e_profession = e_profession;
        this.e_skintone = e_skintone;
        this.e_height = e_height;
        this.imagea = imagea;
        this.imageb = imageb;
        this.imagec = imagec;
        this.imaged = imaged;
        this.imagee = imagee;
        this.imagef = imagef;
    }

    public String getE_cast() {
        return e_cast;
    }

    public void setE_cast(String e_cast) {
        this.e_cast = e_cast;
    }

    public String getE_education() {
        return e_education;
    }

    public void setE_education(String e_education) {
        this.e_education = e_education;
    }

    public String getE_profession() {
        return e_profession;
    }

    public void setE_profession(String e_profession) {
        this.e_profession = e_profession;
    }

    public String getE_skintone() {
        return e_skintone;
    }

    public void setE_skintone(String e_skintone) {
        this.e_skintone = e_skintone;
    }

    public String getE_height() {
        return e_height;
    }

    public void setE_height(String e_height) {
        this.e_height = e_height;
    }

    public ModelClass(String imagea, String name, String city, String country, String age) {
        this.imagea = imagea;
        this.name = name;
        this.city = city;
        this.country = country;
        this.age = age;
    }

    public ModelClass()
    {}


    public String getCaste() {
        return caste;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }

    public String getSkintone() {
        return skintone;
    }

    public void setSkintone(String skintone) {
        this.skintone = skintone;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getImagea() {
        return imagea;
    }

    public void setImagea(String imagea) {
        this.imagea = imagea;
    }

    public String getImageb() {
        return imageb;
    }

    public void setImageb(String imageb) {
        this.imageb = imageb;
    }

    public String getImagec() {
        return imagec;
    }

    public void setImagec(String imagec) {
        this.imagec = imagec;
    }

    public String getImaged() {
        return imaged;
    }

    public void setImaged(String imaged) {
        this.imaged = imaged;
    }

    public String getImagee() {
        return imagee;
    }

    public void setImagee(String imagee) {
        this.imagee = imagee;
    }

    public String getImagef() {
        return imagef;
    }

    public void setImagef(String imagef) {
        this.imagef = imagef;
    }

    public String  getImage() {
        return imagea;
    }

    public void setImage(String image) {
        this.imagea = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
}
