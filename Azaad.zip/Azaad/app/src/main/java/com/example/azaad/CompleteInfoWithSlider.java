package com.example.azaad;

import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderLayout;
import com.smarteist.autoimageslider.SliderView;

public class CompleteInfoWithSlider extends Fragment {
    SliderLayout sliderLayout;
    Button personalinfo,expectation;
    LinearLayout personalifnfolayout,expectaitonlayout;
    UserCompleteDataArray userCompleteDataArray=new UserCompleteDataArray();

    TextView name,country,ageheight,bio,cast,education,profession,income,e_cast,e_education,e_profession,e_skintone,e_height,e_family;
















    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.completeinfowithslider, container, false);
        String value = getArguments().getString("Position");
        int positon;
        Toast.makeText(getActivity(), ""+value, Toast.LENGTH_SHORT).show();
        positon = Integer.parseInt(value);
        String Profile= userCompleteDataArray.Storedata.get(positon).getProfession();
       // Toast.makeText(getActivity(), ""+Profile, Toast.LENGTH_SHORT).show();



        name=view.findViewById(R.id.name);
        country=view.findViewById(R.id.country);
        ageheight=view.findViewById(R.id.ageandheight);
       // height=view.findViewById(R.id.height);
        bio=view.findViewById(R.id.bio);
        cast=view.findViewById(R.id.caste);
        education=view.findViewById(R.id.educatoin);
        profession=view.findViewById(R.id.profession);
        income=view.findViewById(R.id.income);
        e_cast=view.findViewById(R.id.e_cast);
        e_education=view.findViewById(R.id.e_education);
        e_profession=view.findViewById(R.id.e_profession);
        e_skintone=view.findViewById(R.id.e_skintone);
        e_height=view.findViewById(R.id.e_height);
        e_family=view.findViewById(R.id.e_family);


        name.setText(userCompleteDataArray.Storedata.get(positon).getName());
        country.setText(userCompleteDataArray.Storedata.get(positon).getCountry());
       ageheight.setText(userCompleteDataArray.Storedata.get(positon).getAge()+" | "+userCompleteDataArray.Storedata.get(positon).getHeight()+" Feet");
       // height.setText(userCompleteDataArray.Storedata.get(positon).getHeight());
        bio.setText(userCompleteDataArray.Storedata.get(positon).getBio());
        cast.setText(userCompleteDataArray.Storedata.get(positon).getCaste());
        education.setText(userCompleteDataArray.Storedata.get(positon).getEducation());
        profession.setText(userCompleteDataArray.Storedata.get(positon).getProfession());
        income.setText(userCompleteDataArray.Storedata.get(positon).getIncome());
        e_cast.setText(userCompleteDataArray.Storedata.get(positon).getE_cast());
        e_education.setText(userCompleteDataArray.Storedata.get(positon).getE_education());
        e_profession.setText(userCompleteDataArray.Storedata.get(positon).getE_profession());
        e_skintone.setText(userCompleteDataArray.Storedata.get(positon).getE_skintone());
        e_height.setText(userCompleteDataArray.Storedata.get(positon).getE_height());



























        personalinfo=view.findViewById(R.id.personalinfo);
        expectation=view.findViewById(R.id.expectation);
        personalifnfolayout=view.findViewById(R.id.personalinfolayout);
        expectaitonlayout=view.findViewById(R.id.expectationlayout);
        expectaitonlayout.setVisibility(View.GONE);
        expectation.setBackgroundResource(R.drawable.homeitemwithoutbackgorun);
        expectation.setTextColor(Color.parseColor("#EF6121"));

        expectation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                personalifnfolayout.setVisibility(View.GONE);
                expectaitonlayout.setVisibility(View.VISIBLE);
                personalinfo.setBackgroundResource(R.drawable.homeitemwithoutbackgorun);
                personalinfo.setTextColor(Color.parseColor("#EF6121"));
                expectation.setBackgroundResource(R.drawable.homeitembutton);
                expectation.setTextColor(Color.parseColor("#FFFFFF"));


            }
        });


        personalinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                personalifnfolayout.setVisibility(View.VISIBLE);
                expectaitonlayout.setVisibility(View.GONE);

                expectation.setBackgroundResource(R.drawable.homeitemwithoutbackgorun);
                expectation.setTextColor(Color.parseColor("#EF6121"));
                personalinfo.setBackgroundResource(R.drawable.homeitembutton);
                personalinfo.setTextColor(Color.parseColor("#FFFFFF"));


            }
        });






        sliderLayout=view.findViewById(R.id.imageSlider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.SWAP);
        sliderLayout.setSliderTransformAnimation(SliderAnimations.FADETRANSFORMATION);
        sliderLayout.setScrollTimeInSec(4);
        setSliderViews();
       /* sliderLayout = view.findViewById(R.id.imageSlider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.SWAP); //set indicator animation by using SliderLayout.IndicatorAnimations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
        sliderLayout.setSliderTransformAnimation(SliderAnimations.FADETRANSFORMATION);
        sliderLayout.setScrollTimeInSec(4); //set scroll delay in seconds :
        //setSliderViews();
*/
        return view;
    }
    private void setSliderViews() {
        String value = getArguments().getString("Position");
        int positon;
        Toast.makeText(getActivity(), ""+value, Toast.LENGTH_SHORT).show();
        positon = Integer.parseInt(value);
        String imageone=userCompleteDataArray.Storedata.get(positon).getImagea();
        byte[] data = Base64.decode(imageone, Base64.DEFAULT);
        String imagetwo=userCompleteDataArray.Storedata.get(positon).getImageb();
        byte[] data1 = Base64.decode(imagetwo, Base64.DEFAULT);
        String imagethree=userCompleteDataArray.Storedata.get(positon).getImagec();
        byte[] data2 = Base64.decode(imagethree, Base64.DEFAULT);
        String image4=userCompleteDataArray.Storedata.get(positon).getImaged();
        byte[] data3 = Base64.decode(image4, Base64.DEFAULT);
        String image5=userCompleteDataArray.Storedata.get(positon).getImagee();
        byte[] data4 = Base64.decode(image5, Base64.DEFAULT);
        String image6=userCompleteDataArray.Storedata.get(positon).getImagef();
        byte[] data5 = Base64.decode(image6, Base64.DEFAULT);

        for (int i = 0; i <=5; i++) {

            DefaultSliderView sliderView = new DefaultSliderView(getActivity());

            switch (i) {
                case 0:



                    sliderView.setImageByte(data);

                    /*String imagetwo=userCompleteDataArray.Storedata.get(positon).getImageb();
                    String uri=Uri.decode(imageone);
                    Uri uria=Uri.parse(uri);
                    Uri urib=Uri.parse(imagetwo);
                    sliderView.setImageUrl("uria");
*/
                    //sliderView.setImageUrl("https://images.pexels.com/photos/218983/pexels-photo-218983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
                    break;
                case 1:
                    sliderView.setImageByte(data1);
                   // sliderView.setImageUrl("https://images.pexels.com/photos/218983/pexels-photo-218983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
                    break;
                case 2:
                    sliderView.setImageByte(data2);
                    //sliderView.setImageUrl("https://images.pexels.com/photos/747964/pexels-photo-747964.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260");
                    break;
                case 3:
                    sliderView.setImageByte(data3);
                    //sliderView.setImageUrl("https://images.pexels.com/photos/929778/pexels-photo-929778.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
                    break;
                case 4:
                    sliderView.setImageByte(data4);
                    //sliderView.setImageUrl("https://images.pexels.com/photos/929778/pexels-photo-929778.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
                    break;
                case 5:
                    sliderView.setImageByte(data5);
                    //sliderView.setImageUrl("https://images.pexels.com/photos/929778/pexels-photo-929778.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
                    break;


            }

            sliderView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
            /*sliderView.setDescription("Name\n" +
                    "26 year old  " + (i + 1));
            final int finalI = i;

            sliderView.setOnSliderClickListener(new SliderView.OnSliderClickListener() {
                @Override
                public void onSliderClick(SliderView sliderView) {
                    Toast.makeText(getContext(), "This is slider " + (finalI + 1), Toast.LENGTH_SHORT).show();

                }
            });*/

            //at last add this view in your layout :
            sliderLayout.addSliderView(sliderView);
        }

    }
}
