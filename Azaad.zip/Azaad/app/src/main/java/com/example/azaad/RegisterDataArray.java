package com.example.azaad;

import java.util.ArrayList;
import java.util.List;

public class RegisterDataArray {
    public static String id;
    public static List<String> Storedata= new ArrayList<String>();
    public static int count;
}
