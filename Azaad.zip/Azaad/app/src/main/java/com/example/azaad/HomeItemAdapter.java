package com.example.azaad;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeItemAdapter extends ArrayAdapter<ModelClass> {
    ArrayList<ModelClass> data;
    Context context;
    HomeItemAdapter(Context context, ArrayList<ModelClass> data) {
        super(context, R.layout.home_items, data);

        this.data = data;
        this.context = context;


    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.home_items, null);
        CircleImageView imageView;
        ImageView add_to_faveroute;
        TextView name,city_country,age;
        final Button connect;
        imageView=view.findViewById(R.id.image);
        name=view.findViewById(R.id.name);
        city_country=view.findViewById(R.id.city_country);
        age=view.findViewById(R.id.age);
        add_to_faveroute=view.findViewById(R.id.add_to_favorat);
        connect=view.findViewById(R.id.connect);
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragment=null;
                fragment=new CompleteInfoWithSlider();
                FragmentTransaction fragmentTransaction = ((MainActivity)context).getSupportFragmentManager().beginTransaction();
                Bundle args = new Bundle();
                args.putString("Position",""+position);
                fragment.setArguments(args);
                fragmentTransaction.replace(R.id.homecantainer, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                //Toast.makeText(getContext(), "click", Toast.LENGTH_SHORT).show();
            }
        });
       // imageView.setImageResource(data.get(position).getImage());
       imageView.setImageBitmap(Utility.stringToBitmap(data.get(position).getImage()));
       String cty,cntry,cty_cntry;
       cty=data.get(position).getCity();
       cntry=data.get(position).getCountry();
       cty_cntry=cty+", "+cntry;
       name.setText(data.get(position).getName());
       city_country.setText(cty_cntry);
       age.setText(data.get(position).getAge());

       return view;
    }

}
