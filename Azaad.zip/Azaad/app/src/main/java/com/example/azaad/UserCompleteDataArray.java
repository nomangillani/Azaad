package com.example.azaad;

import java.util.ArrayList;
import java.util.List;

public class UserCompleteDataArray {
    public static ArrayList<ModelClass> Storedata= new ArrayList<ModelClass>();
    //public static ModelClass Storedata= new ModelClass();

}
